# ========================================
# Controllo Webcam Integrata 
# ========================================

# File per salvare gli ID delle webcam
$webcamFile = "$env:USERPROFILE\Documents\scripts\webcams.json"

# Array iniziale
$webcams = @()

# FriendlyName comuni
$commonFriendlyNames = @(
    "Integrated Webcam",
    "USB2.0 UVC VGA Webcam",
    "USB2.0 UVC HD Webcam",
    "USB2.0 UVC WebCam",
    "Integrated Camera",
    "HD WebCam",
    "VGA WebCam",
    "Lenovo EasyCamera",
    "HP Wide Vision HD Camera",
    "Logitech HD Webcam C270",
    "Microsoft LifeCam VX-5000",
    "Realtek USB2.0 PC Camera",
    "Chicony USB2.0 Camera",
    "SunplusIT USB2.0 Camera",
    "OmniVision USB2.0 Camera",
    "OV5647 Camera",
    "OV2740 Camera",
    "Intel RealSense Camera",
    "ASUS USB2.0 UVC HD Webcam"
)

# Funzioni colori
function Write-Title($text) { Write-Host $text -ForegroundColor Cyan }
function Write-Option($text) { Write-Host $text -ForegroundColor Yellow }
function Write-Success($text) { Write-Host $text -ForegroundColor DarkGreen }
function Write-WarningMsg($text) { Write-Host $text -ForegroundColor DarkYellow }
function Write-ErrorMsg($text) { Write-Host $text -ForegroundColor DarkRed }
function Write-Border { Write-Title "+=========================================+" }

# ========================================
# Funzioni webcam
# ========================================
function Enable-Webcams {
    if ($webcams.Count -eq 0) { Write-WarningMsg ":c Nessuna Webcam registrata :c"; return }
    foreach ($id in $webcams) {
        $device = Get-PnpDevice -InstanceId $id -ErrorAction SilentlyContinue
        if ($device.Status -eq "OK") {
            Write-WarningMsg "c: Webcam gia' abilitata c:"
        } else {
            try {
                Start-Process powershell -WindowStyle Hidden -ArgumentList "Enable-PnpDevice -InstanceId '$id' -Confirm:`$false -ErrorAction SilentlyContinue" -Wait
                Write-Success "c: Webcam abilitata. c:"
            } catch {
                Write-ErrorMsg "-.- Impossibile abilitare (non disponibile) -.-"
            }
        }
    }
}

function Disable-Webcams {
    if ($webcams.Count -eq 0) { Write-WarningMsg ":c Nessuna Webcam registrata :c"; return }
    foreach ($id in $webcams) {
        $device = Get-PnpDevice -InstanceId $id -ErrorAction SilentlyContinue
        if ($device.Status -ne "OK") {
            Write-WarningMsg "c: Webcam gia' disabilitata c:"
        } else {
            try {
                Start-Process powershell -WindowStyle Hidden -ArgumentList "Disable-PnpDevice -InstanceId '$id' -Confirm:`$false -ErrorAction SilentlyContinue" -Wait
                Write-Success ":c Webcam disabilitata. :c"
            } catch {
                Write-ErrorMsg "-.- Impossibile disabilitare (probabilmente in uso) -.-"
            }
        }
    }
}

# ========================================
# Funzione ricerca webcam (ritorna array di ID)
# ========================================
function Search-Webcams {
    # Rimuove ghost device invisibile
    Get-PnpDevice | Where-Object { $commonFriendlyNames -contains $_.FriendlyName -and $_.Status -eq "Unknown" } |
        ForEach-Object { try { Disable-PnpDevice -InstanceId $_.InstanceId -Confirm:$false -ErrorAction Stop } catch {} }

    Start-Sleep 0.2

    # Ricerca webcam comuni
    $allWebcams = Get-PnpDevice | Where-Object { $commonFriendlyNames -contains $_.FriendlyName -and $_.InstanceId -ne $null }
    $foundWebcams = $allWebcams | Where-Object { $_.Status -ne "Unknown" }

    if ($foundWebcams.Count -eq 0) {
        # Ricerca generica
        $genericWebcams = Get-PnpDevice | Where-Object {
            ($_.FriendlyName -match "Camera" -or $_.FriendlyName -match "WebCam") -and $_.InstanceId -ne $null
        } | Where-Object { $_.Status -ne "Unknown" }

        if ($genericWebcams.Count -eq 0) { return @() }

        # Selezione automatica tutte le webcam trovate
        return $genericWebcams | ForEach-Object { $_.InstanceId }
    } else {
        # Webcam comuni trovate
        return $foundWebcams | ForEach-Object { $_.InstanceId }
    }
}

# ========================================
# Carica webcam da file o ricerca se vuoto
# ========================================
if (Test-Path $webcamFile) {
    try {
        $webcams = Get-Content $webcamFile | ConvertFrom-Json
    } catch {
        $webcams = Search-Webcams
        if ($webcams.Count -gt 0) { $webcams | ConvertTo-Json | Set-Content $webcamFile }
    }
} else {
    $webcams = Search-Webcams
    if ($webcams.Count -gt 0) { $webcams | ConvertTo-Json | Set-Content $webcamFile }
}

# ========================================
# Menu principale
# ========================================
$menuOptions = @(
    "Accendi le webcam selezionate",
    "Spegni le webcam selezionate",
    "Reset installazione webcam",
    "Esci"
)

do {
    Clear-Host
    Write-Border
    Write-Title "       CONTROLLO WEBCAM INTEGRATA"
    Write-Border
    for ($i=0; $i -lt $menuOptions.Count; $i++) {
        Write-Option "$($i+1)) $($menuOptions[$i])"
    }
    Write-Border

    $choice = Read-Host "Seleziona un'opzione (1-4)"
    
    switch ($choice) {
        "1" { Enable-Webcams; Start-Sleep 1 }
        "2" { Disable-Webcams; Start-Sleep 1 }
        "3" {
            Write-WarningMsg "Installazione resettata. Eseguo nuova ricerca webcam..."
            if (Test-Path $webcamFile) { Remove-Item $webcamFile -Force }
            $webcams = @()
            # Aggiorna array subito dopo la ricerca
            $webcams = Search-Webcams
            if ($webcams.Count -gt 0) { 
                $webcams | ConvertTo-Json | Set-Content $webcamFile
                Write-Success "Nuova installazione completata. Puoi ora usare tutte le funzioni del menu."
            } else {
                Write-ErrorMsg "Non è stata trovata nessuna webcam."
            }
            Start-Sleep 1
        }
        "4" {
            Write-Option "Bye Bye!"; Start-sleep 1
            try { Set-ExecutionPolicy Restricted -Scope CurrentUser -Force -ErrorAction SilentlyContinue } catch {}
            exit
        }
        Default { Write-ErrorMsg "Opzione non valida, riprova."; Start-Sleep 1 }
    }

} while ($choice -ne "4")
